import { Component } from '@angular/core';
import {
  RouterLink,
  RouterLinkActive
} from '@angular/router';
import { AdminMenuItem } from '../models/admin-menu.model';

@Component({
  selector: 'app-admin-sidebar',
  standalone: true,
  imports: [
    RouterLink,
    RouterLinkActive
  ],
  templateUrl: './admin-sidebar.component.html',
  styleUrl: './admin-sidebar.component.css'
})
export class AdminSidebarComponent {

  menuItems: AdminMenuItem[] = [

    {
      label: 'Dashboard',
      icon: 'bi bi-grid',
      route: '/admin/dashboard'
    },

    {
      label: 'Bookings',
      icon: 'bi bi-calendar-check',
      route: '/admin/bookings'
    },

    {
      label: 'Content',
      icon: 'bi bi-images',
      route: '/admin/content'
    },

    {
      label: 'Finance',
      icon: 'bi bi-wallet2',
      route: '/admin/finance'
    },

    {
      label: 'Reports',
      icon: 'bi bi-file-earmark-bar-graph',
      route: '/admin/reports'
    }

  ];
}