import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from '../../../environments/environment';

import { RegisterRequest } from '../../features/auth/models/register-request.model';
import { ForgotPasswordRequest } from '../../features/auth/models/forgot-password-request.model';
import { ResetPasswordRequest } from '../../features/auth/models/reset-password-request.model';
import { LoginRequest } from '../../features/auth/models/login-request.model';
import { LoginResponse } from '../../features/auth/models/login-response.model';
import { ResendOtpRequest } from '../../features/auth/models/resend-otp-request.model';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private http: HttpClient) {}

  // ============================================
  // Register
  // ============================================

  register(request: RegisterRequest): Observable<any> {
    return this.http.post<any>(`${environment.apiUrl}/auth/register`, request);
  }

  // ============================================
  // Login
  // ============================================

  login(request: LoginRequest): Observable<{
    success: boolean;
    message: string;
    data: LoginResponse;
  }> {
    return this.http.post<{
      success: boolean;
      message: string;
      data: LoginResponse;
    }>(`${environment.apiUrl}/auth/login`, request);
  }

  // ============================================
  // Verify Email
  // ============================================

  verifyEmail(
    farmHouseId: number,
    userId: number,
    token: string,
  ): Observable<any> {
    return this.http.get<any>(`${environment.apiUrl}/auth/verify-email`, {
      params: {
        farmHouseId: farmHouseId,
        userId: userId,
        token: token,
      },
    });
  }

  // ============================================
  // Verify OTP
  // ============================================

  verifyOtp(request: {
    farmHouseId: number;
    userId: number;
    otpCode: string;
  }): Observable<any> {
    return this.http.post<any>(
      `${environment.apiUrl}/auth/verify-otp`,
      request,
    );
  }

  // ============================================
  // Resend OTP
  // ============================================

  resendOtp(request: ResendOtpRequest): Observable<any> {
    return this.http.post<any>(
      `${environment.apiUrl}/auth/resend-otp`,
      request,
    );
  }

  // ============================================
  // Forgot Password
  // ============================================

  forgotPassword(request: ForgotPasswordRequest): Observable<any> {
    return this.http.post<any>(
      `${environment.apiUrl}/auth/forgot-password`,
      request,
    );
  }

  // ============================================
  // Reset Password
  // ============================================

  resetPassword(request: ResetPasswordRequest): Observable<any> {
    return this.http.post<any>(
      `${environment.apiUrl}/auth/reset-password`,
      request,
    );
  }
}
