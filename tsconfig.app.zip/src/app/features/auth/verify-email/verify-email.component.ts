import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { RouterLink } from '@angular/router';
import Swal from 'sweetalert2';

import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-verify-email',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './verify-email.component.html',
  styleUrl: './verify-email.component.css',
})
export class VerifyEmailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private authService = inject(AuthService);
  private fb = inject(FormBuilder);

  // ============================================
  // User / FarmHouse Information
  // ============================================

  userId!: number;
  farmHouseId!: number;

  // ============================================
  // Verification Status
  // ============================================

  isEmailVerified = false;
  isMobileVerified = false;

  // ============================================
  // Page State
  // ============================================

  isLoading = true;
  isVerifyingOtp = false;
  isResendingOtp = false;

  message = '';

  // ============================================
  // OTP Form
  // ============================================

  otpForm: FormGroup;

  constructor() {
    this.otpForm = this.fb.group({
      otpCode: ['', [Validators.required, Validators.pattern(/^[0-9]{6}$/)]],
    });
  }

  // ============================================
  // Form Controls
  // ============================================

  get f() {
    return this.otpForm.controls;
  }

  // ============================================
  // Initial Load
  // ============================================

  ngOnInit(): void {
    const userId = this.route.snapshot.queryParamMap.get('userId');
    const farmHouseId = this.route.snapshot.queryParamMap.get('farmHouseId');

    const token = this.route.snapshot.queryParamMap.get('token');

    // --------------------------------------------
    // Validate Required IDs
    // --------------------------------------------

    if (!userId || !farmHouseId) {
      this.isLoading = false;

      this.message =
        'Verification information is missing. Please register again.';

      return;
    }

    this.userId = Number(userId);
    this.farmHouseId = Number(farmHouseId);

    // --------------------------------------------
    // Email Link Case
    // --------------------------------------------
    // If token exists, user came from email link.
    // First verify email, then load latest status.
    // --------------------------------------------

    if (token) {
      this.verifyEmailFromLink(token);
      return;
    }

    // --------------------------------------------
    // Normal Registration Redirect Case
    // --------------------------------------------
    // No token means user came directly after registration.
    // Load current verification status.
    // --------------------------------------------

    this.loadVerificationStatus();
  }

  // ============================================
  // Verify Email From Email Link
  // ============================================

  private verifyEmailFromLink(token: string): void {
    this.isLoading = true;

    this.authService
      .verifyEmail(this.farmHouseId, this.userId, token)
      .subscribe({
        next: (response: any) => {
          this.isLoading = false;

          this.message = response.message ?? 'Email verification completed.';

          // --------------------------------------
          // Always load latest status
          // --------------------------------------

          this.loadVerificationStatus();
        },

        error: (error) => {
          this.isLoading = false;

          this.message = error.error?.message ?? 'Email verification failed.';

          // --------------------------------------
          // Even if email verification fails,
          // load current status.
          // --------------------------------------

          this.loadVerificationStatus();
        },
      });
  }

  // ============================================
  // Load Verification Status
  // ============================================

  private loadVerificationStatus(): void {
    this.isLoading = true;

    this.authService
      .getVerificationStatus(this.farmHouseId, this.userId)
      .subscribe({
        next: (response: any) => {
          this.isLoading = false;

          if (!response.success || !response.data) {
            this.message =
              response.message ?? 'Unable to load verification status.';

            return;
          }

          this.isEmailVerified = response.data.isEmailVerified;

          this.isMobileVerified = response.data.isMobileVerified;

          // --------------------------------------
          // Both Verification Completed
          // --------------------------------------

          if (this.isEmailVerified && this.isMobileVerified) {
            this.message =
              'Your email and mobile number have been verified successfully.';

            this.redirectToLogin();

            return;
          }

          // --------------------------------------
          // Email Pending
          // --------------------------------------

          if (!this.isEmailVerified) {
            this.message =
              'Please check your email and click the verification link.';
          }

          // --------------------------------------
          // Mobile Pending
          // --------------------------------------

          if (this.isEmailVerified && !this.isMobileVerified) {
            this.message =
              'Your email is verified. Please verify your mobile number using the OTP.';
          }
        },

        error: (error:any) => {
          this.isLoading = false;

          this.message =
            error.error?.message ?? 'Unable to load verification status.';
        },
      });
  }

  // ============================================
  // Verify OTP
  // ============================================

  verifyOtp(): void {
    if (this.otpForm.invalid) {
      this.otpForm.markAllAsTouched();
      return;
    }

    this.isVerifyingOtp = true;

    const otpCode = this.otpForm.value.otpCode;

    this.authService
      .verifyOtp({
        userId: this.userId,
        farmHouseId: this.farmHouseId,
        otpCode: otpCode,
      })
      .subscribe({
        next: (response: any) => {
          this.isVerifyingOtp = false;

          if (!response.success) {
            Swal.fire({
              icon: 'error',
              title: 'OTP Verification Failed',
              text: response.message ?? 'Invalid OTP.',
            });

            return;
          }

          this.otpForm.reset();

          // --------------------------------------
          // Refresh BOTH statuses
          // --------------------------------------

          this.loadVerificationStatus();
        },

        error: (error) => {
          this.isVerifyingOtp = false;

          Swal.fire({
            icon: 'error',
            title: 'OTP Verification Failed',
            text: error.error?.message ?? 'Invalid OTP.',
          });
        },
      });
  }

  // ============================================
  // Resend OTP
  // ============================================

  resendOtp(): void {
    if (!this.userId || !this.farmHouseId || this.isResendingOtp) {
      return;
    }

    // --------------------------------------------
    // If mobile is already verified,
    // no need to resend OTP.
    // --------------------------------------------

    if (this.isMobileVerified) {
      Swal.fire({
        icon: 'info',
        title: 'Already Verified',
        text: 'Your mobile number is already verified.',
      });

      return;
    }

    this.isResendingOtp = true;

    this.authService
      .resendOtp({
        userId: this.userId,
        farmHouseId: this.farmHouseId,
      })
      .subscribe({
        next: (response: any) => {
          this.isResendingOtp = false;

          if (!response.success) {
            Swal.fire({
              icon: 'error',
              title: 'Unable to Resend OTP',
              text: response.message ?? 'Unable to resend OTP.',
            });

            return;
          }

          Swal.fire({
            icon: 'success',
            title: 'OTP Sent',
            text:
              response.message ??
              'A new OTP has been sent to your WhatsApp number.',
            timer: 2000,
            showConfirmButton: false,
          });
        },

        error: (error) => {
          this.isResendingOtp = false;

          Swal.fire({
            icon: 'error',
            title: 'Unable to Resend OTP',
            text:
              error.error?.message ??
              'Something went wrong while resending OTP.',
          });
        },
      });
  }

  // ============================================
  // Redirect To Login
  // ============================================

  private redirectToLogin(): void {
    Swal.fire({
      icon: 'success',
      title: 'Verification Complete',
      text: 'Your account has been verified successfully.',
      timer: 1800,
      showConfirmButton: false,
    }).then(() => {
      this.router.navigate(['/login']);
    });
  }
}
